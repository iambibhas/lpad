# -*- coding: utf-8 -*-

__about__ = """
This project lays the foundation for all other Pinax starter projects. It
provides the project directory layout and some key infrastructure apps on
which the other starter projects are based.
"""
