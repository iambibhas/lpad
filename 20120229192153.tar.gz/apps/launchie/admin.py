from django.contrib import admin
from launchie.models import Project

admin.site.register(Project)
