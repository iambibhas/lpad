#
# App: Language
# admin.py
#

from django.contrib import admin
from language.models import Language

admin.site.register(Language)
